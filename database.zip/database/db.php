<?php

class db {

    public $host, $username, $password, $database, $link;

    function __construct($host, $username, $password, $database) {
        $this->host = $host;
        $this->username = $username;
        $this->password = $password;
        $this->database = $database;
    }

    function conectdb() {
        $this->link = mysqli_connect($this->host, $this->username, $this->password, $this->database);
        if ($this->link) {
            $suscess = TRUE;
        } else {
            $suscess = FALSE;
        }
    }

    function insertuser($username, $Password, $secq, $secA) {
   $query = "INSERT INTO `users` (`User_ID`, `User_DisplayName`, `User_Password`, `User_SecQuestionAnwser`, `User_SecQeustion`) VALUES (NULL, '$username', '$Password', '$secq', '$secA');";

        if (mysqli_query($this->link, $query)) {
            $Saved = TRUE;
        } else {
            $Saved = FALSE;
        }
    }

    function display() {
        $query = "SELECT * FROM `users`";
        $result = mysqli_query($this->link, $query);
        while ($row = mysqli_fetch_array($result, 1)) {
            $id = $row['User_ID'];
            $name = $row['User_DisplayName'];
            $password = $row['User_Password'];
            $q = $row['User_SecQeustion'];
            $a = $row['User_SecQuestionAnwser'];

            echo "<form action ='edit.php'>"
            . "<input type='hidden' name='id' value='$id' />";
            echo $name . " " . " " . $password . " " . $q . " " . $a . " ";
            echo " <input type='submit' value='edit' name='edit'/>"
            . "</form>";
        }
    }

    function editsaveddata($id) {
        $query = "SELECT * FROM `users` WHERE `User_ID`='$id'";
        $result = mysqli_query($this->link, $query);
        while ($row = mysqli_fetch_array($result, 1)) {
            $id = $row['User_ID'];
            $name = $row['User_DisplayName'];
            $password = $row['User_Password'];
            $q = $row['User_SecQeustion'];
            $a = $row['User_SecQuestionAnwser'];

            echo "<form>"
            . "<input type='hidden' name='id' value='$id'/>"
            . "UserName" . "<input type='text' value = '$name' name = 'username'/><br >"
            . "Password" . "<input type='text' value = '$password' name = 'password'/><br >";
            echo"<select name = 'secq'>";
            for ($index = 1; $index < 5; $index++) {
                if ($index == $q) {
                    echo"<option>" . $index . "</option>";
                } else {
                    echo"<option>" . $index . "</option>";
                }
            }
            echo "</select>";
            echo"</form>";
        }
    }
    
    function update($id,$username, $Password, $secq)
    {
        $query ="UPDATE `users` SET `User_DisplayName` = '$username', `User_Password` = '$Password', `User_SecQuestionAnwser` = '$secq' WHERE `users`.`User_ID` = $id;";
        mysqli_query($this->link, $query);
    
        header('location:viewdata.php');
    }

}

$connectobbject = new db('localhost', 'E-Kayusers', 'password', 'e-kayusers');

$connectobbject->conectdb();

