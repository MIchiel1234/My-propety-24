<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <form method="POST" enctype="multipart/form-data" action="<?PHP echo $_SERVER['PHP_SELF'];?>">
            <input type="text" name="Name" value="" />
            <input type="text" name="Password" value="" />
            <select name="secq">
                <option>--Select value--</option>
                <?php
                for ($index = 1; $index <5 ; $index++) {
                    echo "<option>".$index."</option>";
                }
                ?>7
            </select>
            <select name="seca">
                <option>--Select value--</option>
                <?php
                for ($index = 5; $index <10 ; $index++) {
                    echo "<option>".$index."</option>";
                }
                ?>
            </select>
            <input type="submit" value="Save" name="Save" />
        </form>
        <?php
        if(isset($_POST['Save']))
        {
        $Name = $_POST['Name'];
        $Password = $_POST['Password'];
        $secq = $_POST['secq'];
        $seca = $_POST['seca'];
        require_once './db.php';
        $connectobbject->insertuser($Name,$Password,$secq,$seca);
        }
        ?>
    </body>
</html>
