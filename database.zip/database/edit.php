<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <form name="edit">
            <input type="submit" value="save" name="save" /> 
        </form>
        <?php
         require_once './db.php';
          $id = $_GET['id'];
        $connectobbject->editsaveddata($id);
        
        if(isset($_GET['save']))
        {
            $username = $_GET['username'];
            $pass = $_GET['password'];
            $secq = $_GET['secq'];
            
         $connectobbject->update($id,$username,$pass,$secq);
        }
        
        ?>
    </body>
</html>
